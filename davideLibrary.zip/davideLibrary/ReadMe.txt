====================================READme!==============================================
*open the 'davideLibrary' file in any path you extracted it via vscode
*just run 
	venv\Scripts\activate
		after opening the file in the vscode, make sure that this is the file it runs on [ PS C:\Users\Jess Anthony Tahil\Desktop\davideLibrary> ]
*after that just run the manage.py code
	python manage.py runserver


